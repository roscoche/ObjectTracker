/*
 * Copyright (C) 2016 roscoche
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * @author Felipe Roscoche
 * @website roscoche.com
 */

package objecttracking;

import com.googlecode.javacv.CanvasFrame;
import com.googlecode.javacv.FrameGrabber;
import com.googlecode.javacv.OpenCVFrameGrabber;
import static com.googlecode.javacv.cpp.opencv_core.IPL_DEPTH_8U;
import com.googlecode.javacv.cpp.opencv_core.IplImage;
import static com.googlecode.javacv.cpp.opencv_core.cvAbsDiff;
import static com.googlecode.javacv.cpp.opencv_highgui.cvShowImage;
import static com.googlecode.javacv.cpp.opencv_imgproc.CV_RGB2GRAY;
import static com.googlecode.javacv.cpp.opencv_imgproc.CV_THRESH_OTSU;
import static com.googlecode.javacv.cpp.opencv_imgproc.cvCvtColor;
import static com.googlecode.javacv.cpp.opencv_imgproc.cvDilate;
import static com.googlecode.javacv.cpp.opencv_imgproc.cvErode;
import static com.googlecode.javacv.cpp.opencv_imgproc.cvThreshold;


/*
 
  @author roscoche

 */
public class ObjectTracking {
    //This function finds the countours and draws them into the original image.

    

    public static void main(String args[]) {
        TrackNTag objt=new TrackNTag();
        IplImage contorno;
        IplImage img, imgOtsu;
        IplImage primFrame, bgOtsu = null;
        IplImage grayImage;
        IplImage aux;
        IplImage soma;
        IplImage ImgDif;
        boolean flag1oFrame = true;
        CanvasFrame vidContornos = new CanvasFrame("Video Contornos");

        //Set Canvas frame to close on exit
        vidContornos.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        //capture = new VideoFileSource("video.avi");

        //Declare FrameGrabber to import video from "video.mp4"
        FrameGrabber grabber = new OpenCVFrameGrabber("videos/v4.avi");

        try {

            //Start grabber to capture video
            grabber.start();

            //Declare img as IplImage
            while (true) {

                //inser grabed video fram to IplImage img
                if (flag1oFrame) {
                    primFrame = grabber.grab();
                    if (primFrame != null) {
                        bgOtsu = IplImage.create(primFrame.width(), primFrame.height(), IPL_DEPTH_8U, 1);
                        cvCvtColor(primFrame, bgOtsu, CV_RGB2GRAY);
                        cvThreshold(bgOtsu, bgOtsu, 100, 255, CV_THRESH_OTSU);
                        //cvShowImage("primeiro frame otsu", bgOtsu);
                        //cvWaitKey();
                        //cvSaveImage("primeiro frame.jpg", bgOtsu);
                        flag1oFrame = false;
                    } else {
                        break;
                    }
                } else {
                    img = grabber.grab();

                    if (img != null) {

                        imgOtsu = IplImage.create(img.width(), img.height(), IPL_DEPTH_8U, 1);

                        aux = IplImage.create(img.width(), img.height(), IPL_DEPTH_8U, 1);

                        ImgDif = IplImage.create(img.width(), img.height(), IPL_DEPTH_8U, 1);
                        cvCvtColor(img, aux, CV_RGB2GRAY);
                        //cvSplit(img, b, g, r, null);
                        //cvSplit(img, null, null, aux, null);
                        cvThreshold(aux, imgOtsu, 127, 255, CV_THRESH_OTSU);

                        //imgOtsu=new Mediana(1, imgOtsu).getImagemMediana();
                        //cvErode(imgOtsu, imgOtsu, null, 2);
                        //
                        cvAbsDiff(bgOtsu, imgOtsu, ImgDif);
                        //cvSmooth(ImgDif, ImgDif, CV_MEDIAN, 19, 0, 0, 0);
                        //cvShowImage("diferenca", ImgDif);

                        cvErode(ImgDif, ImgDif, null, 6);
                        cvDilate(ImgDif, ImgDif, null, 12);
                        //cvSmooth(ImgDif, ImgDif, CV_MEDIAN, 19, 0, 0, 0);
                        //cvShowImage("diferenca erode", ImgDif);                    
                        //cvShowImage("diferenca erode dilate", ImgDif);
                        //cvWaitKey();
                        //cvSaveImage("diferenca.jpg", ImgDif);
                        //System.out.println("imgdiff "+ImgDif.nChannels()+" img "+img.nChannels());
                        
                        contorno = objt.trackBox(ImgDif, img);
                        //System.out.println("chegou");
                    } else {
                        break;
                    }

                    vidContornos.setCanvasSize(grabber.getImageWidth(), grabber.getImageHeight());
                    vidContornos.showImage(contorno);

                }

            }
        } catch (FrameGrabber.Exception e) {
        }
    }
}
